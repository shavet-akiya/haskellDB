{-# LANGUAGE DataKinds #-}
{-# LANGUAGE DeriveGeneric #-}
{-# LANGUAGE FlexibleInstances #-}
{-# LANGUAGE GeneralizedNewtypeDeriving #-}
{-# LANGUAGE MultiParamTypeClasses #-}
{-# LANGUAGE OverloadedStrings #-}
{-# LANGUAGE RankNTypes #-}
{-# LANGUAGE ScopedTypeVariables #-}
{-# LANGUAGE TypeOperators #-}

module Main where

import qualified Data.Text as T
import Database.MongoDB (Action, Document, Host (..), PortID (..), access, allCollections, close, connect, insert, master, runCommand, (=:))
import MyLib
import Network.Wai.Handler.Warp
import Prelude.Compat
import Prelude ()

main :: IO ()
main = do
  print ("setting mongodb" :: String)

  let host = Host "localhost" (PortNumber 27017)
  pipe <- connect host
  let mongo_run = access pipe master ""

  print ("starting server" :: String)
  run 8081 (app pipe)
